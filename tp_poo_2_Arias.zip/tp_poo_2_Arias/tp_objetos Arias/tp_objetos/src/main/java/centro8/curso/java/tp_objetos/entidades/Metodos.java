package centro8.curso.java.tp_objetos.entidades;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Metodos {


    
    public static List<Vehiculo> listaVehiculos() {
        List<Vehiculo> lista = new ArrayList<>();
        lista.add(new Auto("Peugeot", "206", 4, 200000));
        lista.add(new Moto("Honda", "Titan", 125, 60000));
        lista.add(new Auto("Peugeot", "208", 5, 250000));
        lista.add(new Moto("Yamaha", "YBR", 160, 80500.50));
        return lista;
    }

     // metodo para obtener vehiculo mas caro
    public static Vehiculo vehiculoMasCaro(List<Vehiculo> lista) {
        return Collections.max(lista, Comparator.comparingDouble(Vehiculo::getPrecio));
    }

    public static Vehiculo vehiculoMasBarato(List<Vehiculo> lista) {
        return Collections.min(lista, Comparator.comparingDouble(Vehiculo::getPrecio));
    }

public static void vehiculosConLetraY(List<Vehiculo> lista, char letra) {
    lista.stream()
         .filter(v -> v.getModelo().toLowerCase().contains(String.valueOf(letra).toLowerCase()))
         .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo() + " $" + String.format("%,.2f", v.getPrecio())));
}

    public static List<Vehiculo> ordenarMayorAMenor(List<Vehiculo> lista) {
        return lista.stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .collect(Collectors.toList());
    }

    public static List<Vehiculo> ordenarOrdenNatural(List<Vehiculo> lista) {
        return lista.stream()
                .sorted()
                .collect(Collectors.toList());

    }

}