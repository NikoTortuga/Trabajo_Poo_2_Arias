package centro8.curso.java.tp_objetos.entidades;

final public class Moto extends Vehiculo {
    public int cilindrada;

    public Moto(String marca, String modelo, int cilindrada, double precio) {
        super(marca, modelo, precio);
        this.cilindrada=cilindrada;
    }

    @Override
    public String toString() {
        return "Marca: " + marca +
                " //Modelo: " + modelo +
                " //Cilindrada:" + cilindrada +
                "c //Precio: $" + String.format("%,.2f", precio);
    }

}
