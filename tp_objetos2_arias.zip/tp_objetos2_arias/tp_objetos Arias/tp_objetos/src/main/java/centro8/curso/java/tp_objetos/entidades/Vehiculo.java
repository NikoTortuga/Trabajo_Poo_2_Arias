package centro8.curso.java.tp_objetos.entidades;
import lombok.Setter;
import lombok.Getter;

@Getter

@Setter


public abstract class Vehiculo implements Comparable<Vehiculo> {
    public String marca;
    public String modelo;
    public double precio;

    public Vehiculo(String marca, String modelo, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    @Override
    public int compareTo(Vehiculo otro) {
        //compare to es un metodo que compara 2 objetos y devuelve un valor
        // 
        int porMarca = this.marca.compareTo(otro.marca);
        if (porMarca != 0)
            return porMarca;

        int porModelo = this.modelo.compareTo(otro.modelo);
        if (porModelo != 0)
            return porModelo;

        return Double.compare(this.precio, otro.precio);
    }

}
