package centro8.curso.java.tp_objetos.test;

import centro8.curso.java.tp_objetos.entidades.*;

import java.util.*;

public class TestVehiculos {
    public static void main(String[] args) {
        List<Vehiculo> vehiculos = Metodos.listaVehiculos();

        System.out.println("");

        // *************************************** LISTA DE 4 VEHICULOS
        for (Vehiculo v : vehiculos) {
            System.out.println(v.toString());
        }
        System.out.println("");
        System.out.println("=============================");
        System.out.println("");

        // *************************************** CARO, BARATRO Y LETRA Y

        System.out.println("Vehículo más caro: " +  
        Metodos.vehiculoMasCaro(vehiculos).getMarca() + " " + 
        Metodos.vehiculoMasCaro(vehiculos).getModelo());

        System.out.println("Vehículo más barato: " +  
        Metodos.vehiculoMasBarato(vehiculos).getMarca() + " " + 
        Metodos.vehiculoMasBarato(vehiculos).getModelo());

        System.out.print("Vehículo que contiene en el modelo la letra Y: ");
        Metodos.vehiculosConLetraY(vehiculos, 'Y');

        System.out.println("");
        System.out.println("=============================");
        System.out.println("");

        // *************************************** PRECIO DE MAYOR A MENOR

        System.out.println("Vehículos ordenados por precio de mayor a menor:");
        for (Vehiculo v : Metodos.ordenarMayorAMenor(vehiculos)) {
            System.out.println(v.getMarca() + " " + v.getModelo());
        }
        System.out.println("");
        System.out.println("=============================");
        System.out.println("");

        // *************************************** ORDEN NATURAL
        
        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
        for (Vehiculo v : Metodos.ordenarOrdenNatural(vehiculos)) {
            System.out.println(v.toString());
        }
        System.out.println("");
    }
}
